﻿<?php
?>
<script src="jquery.js"></script>
<script>
  function auth(){
      var login = $("#name").val();
      var pass = $("#pass").val(); 
      var str = "login="+login+"&pass="+pass;
       
      $.ajax({
        type: 'POST',
        url: 'index.html',
        data: str,
        success: function(data_answer){
              $("h1").html(data_answer);
        }
    });
  }
</script>
<html>
<body>
<div class="container">
	<div class="header">
		<meta charset="UTF-8">
		<LINK href="css/shop_sell_boucets.css" type="text/css" rel="stylesheet">
		<style>a {text-decoration: none;} </style>
		<ul class="menu">
			<li><a href="Index.html"><img class="logo" src="img/gift.png" /></a></li>		
			<li><a style="text-decoration=none;" href="Index.html" class="menuButton">Главная</a></li>
			<li><a href="Catalog.php" class="menuButton">Каталог букетов</a></li>
			<li><a href="Contacts.php" class="menuButton">Cделать заказ</a></li>
			<li><a href="LoginForm.php" class="menuButton">Войти/Выйти</a></li>
		</ul>
	</div>
<div class="body">
	<h2>Войти в магазин</h2>
	<form action="Catalog.php" method="POST">
	<p class="labelItem">Имя:</p><input name="name" class="contactsText" type="text" Placeholder="Имя" /></br>
	<p class="labelItem">Пароль:</p><input name="pass" class="contactsText" type="password" Placeholder="Пароль" /></br>
<br>
	<!--<input type="submit" name="contactsSend" value="Войти">&nbsp;&nbsp;&nbsp;&nbsp;-->
	<button onclick="auth()">Войти</button>
	<input type="reset" name="contactsReset" value="Отменить"></br>
	</form>
</div>
<div class="footer">
	<div class="shopAddress">
		<ul>
			<li><b>Магазин "Дарите женщинам цветы!":</b></li>
			<li>Телефон:&nbsp;+7&nbsp;(905)&nbsp;456-67-67</li>
			<li>Е-мэйл:&nbsp;magaizinzvetov@magaizinzvetov.ru</li>
			<li>Адрес:&nbsp;119034 г.Москва, ул.Остоженка, д.12/1, строение 3</li>
		</ul>
	</div>
	<div class="shopAddress1">
		<ul>
			<li>Как нас найти?</li>
			<li>
				<a target=_new href="https://yandex.ru/maps/213/moscow/?ll=37.599310%2C55.742336&z=16&mode=search&ol=geo&ouri=ymapsbm1%3A%2F%2Fgeo%3Fll%3D37.599313%252C55.742337%26spn%3D0.001000%252C0.001000%26text%3D%25D0%25A0%25D0%25BE%25D1%2581%25D1%2581%25D0%25B8%25D1%258F%252C%2520%25D0%259C%25D0%25BE%25D1%2581%25D0%25BA%25D0%25B2%25D0%25B0%252C%2520%25D1%2583%25D0%25BB%25D0%25B8%25D1%2586%25D0%25B0%2520%25D0%259E%25D1%2581%25D1%2582%25D0%25BE%25D0%25B6%25D0%25B5%25D0%25BD%25D0%25BA%25D0%25B0%252C%252012%252F1%25D1%25813%2520">
					<img src="img/ShopAddressMap.jpg" height="74px" />
				</a>
			</li>
		</ul>	
	</div>
	<div class="copyright">
		<b>© Все права защищены</b>
	</div>
</div>
</div>
</body>
</html>